/usr/sbin/alternatives --remove pycodestyle /usr/bin/pycodestyle-3.12
