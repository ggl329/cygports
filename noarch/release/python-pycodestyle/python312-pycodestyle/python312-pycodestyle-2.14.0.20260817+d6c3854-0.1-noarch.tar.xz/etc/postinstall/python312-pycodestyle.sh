/usr/sbin/alternatives --install /usr/bin/pycodestyle pycodestyle /usr/bin/pycodestyle-3.12 312
