;;; magit-version.el --- The Magit version you are using  -*- lexical-binding:t -*-

(setq magit-version "4.7.1")

(provide 'magit-version)

;; Local Variables:
;; version-control: never
;; no-byte-compile: t
;; no-update-autoloads: t
;; coding: utf-8
;; End:
;;; magit-version.el ends here
