;;; Generated package description from embark.el  -*- no-byte-compile: t -*-
(define-package "embark" "1.2" "Conveniently act on minibuffer completions" '((emacs "29.1") (compat "30")) :authors '(("Omar Antolín Camarena" . "omar@matem.unam.mx")) :maintainer '("Omar Antolín Camarena" . "omar@matem.unam.mx") :keywords '("convenience") :url "https://github.com/oantolin/embark")
