/usr/sbin/alternatives --remove flake8 /usr/bin/flake8-3.12
