/usr/sbin/alternatives --install /usr/bin/flake8 flake8 /usr/bin/flake8-3.12 312
