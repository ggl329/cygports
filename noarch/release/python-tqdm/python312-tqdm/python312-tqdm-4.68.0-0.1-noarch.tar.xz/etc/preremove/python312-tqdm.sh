/usr/sbin/alternatives --remove tqdm /usr/bin/tqdm-3.12
