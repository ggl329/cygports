/usr/sbin/alternatives --install /usr/bin/tqdm tqdm /usr/bin/tqdm-3.12 312
