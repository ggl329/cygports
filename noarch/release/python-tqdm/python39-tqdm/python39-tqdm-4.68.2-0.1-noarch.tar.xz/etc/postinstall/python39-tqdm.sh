/usr/sbin/alternatives --install /usr/bin/tqdm tqdm /usr/bin/tqdm-3.9 39
