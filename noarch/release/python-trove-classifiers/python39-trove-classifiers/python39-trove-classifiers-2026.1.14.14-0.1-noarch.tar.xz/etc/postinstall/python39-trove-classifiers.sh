/usr/sbin/alternatives --install /usr/bin/trove-classifiers trove-classifiers /usr/bin/trove-classifiers-3.9 39
