/usr/sbin/alternatives --remove trove-classifiers /usr/bin/trove-classifiers-3.12
