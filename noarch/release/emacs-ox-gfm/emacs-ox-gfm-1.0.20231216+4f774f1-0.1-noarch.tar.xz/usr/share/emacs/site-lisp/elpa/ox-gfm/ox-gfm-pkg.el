;;; Generated package description from ox-gfm.el  -*- no-byte-compile: t -*-
(define-package "ox-gfm" "1.0" "Github Flavored Markdown Back-End for Org Export Engine" '((emacs "26.1") (org "9.1")) :keywords '("org" "wp" "markdown" "github") :url "https://github.com/larstvei/ox-gfm")
