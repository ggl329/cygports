/usr/sbin/alternatives --install /usr/bin/pylsp pylsp /usr/bin/pylsp-3.12 312
