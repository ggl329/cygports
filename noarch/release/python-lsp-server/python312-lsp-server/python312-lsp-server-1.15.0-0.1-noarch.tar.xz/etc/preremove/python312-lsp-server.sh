/usr/sbin/alternatives --remove pylsp /usr/bin/pylsp-3.12
