;;; Generated package description from cond-let.el  -*- no-byte-compile: t -*-
(define-package "cond-let" "1.0.0" "Additional and improved binding conditionals" '((emacs "28.1")) :keywords '("extensions") :url "https://github.com/tarsius/cond-let")
