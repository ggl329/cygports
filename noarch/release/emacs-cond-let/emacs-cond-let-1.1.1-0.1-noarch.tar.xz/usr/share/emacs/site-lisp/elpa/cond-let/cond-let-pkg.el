;;; Generated package description from cond-let.el  -*- no-byte-compile: t -*-
(define-package "cond-let" "1.1.1" "Additional and improved binding conditionals" '((emacs "28.1")) :authors '(("Jonas Bernoulli" . "emacs.cond-let@jonas.bernoulli.dev")) :maintainer '("Jonas Bernoulli" . "emacs.cond-let@jonas.bernoulli.dev") :keywords '("extensions") :url "https://github.com/tarsius/cond-let")
