#!/usr/bin/env python3
"""Extract dependency package names from Python distribution metadata."""

import argparse
import sys
import tarfile
import warnings
import zipfile

from pathlib import Path
from typing import Iterable

from packaging.markers import default_environment
from packaging.metadata import parse_email
from packaging.requirements import InvalidRequirement, Requirement
from packaging.utils import InvalidName, canonicalize_name


def build_parser() -> argparse.ArgumentParser:
    """Build the command-line argument parser."""
    parser = argparse.ArgumentParser(
        description="Extract dependencies from Python distribution metadata."
    )
    parser.add_argument(
        "input",
        type=Path,
        help=(
            "Input metadata file, distribution archive, "
            "or extracted distribution directory."
        ),
    )
    parser.add_argument(
        "--python-version",
        metavar="VERSION",
        help="Python version used to evaluate environment markers.",
    )
    parser.add_argument(
        "--extra",
        action="append",
        default=[],
        metavar="NAME",
        help="Include dependencies for the specified extra. Can be repeated.",
    )
    parser.add_argument(
        "--list-extras",
        action="store_true",
        help="List declared extras and exit.",
    )
    return parser


def parse_python_version(value: str) -> tuple[int, int, int]:
    """Parse a Python version in MAJOR.MINOR or MAJOR.MINOR.PATCH format."""
    parts = value.split(".")

    if (
        len(parts) not in (2, 3)
        or not all(part.isascii() and part.isdecimal() for part in parts)
    ):
        raise ValueError(
            f"Invalid Python version: {value!r}. "
            "Expected MAJOR.MINOR or MAJOR.MINOR.PATCH."
        )

    if len(parts) == 2:
        parts.append("0")

    return tuple(map(int, parts))


def create_environment(
    python_version: tuple[int, int, int] | None,
) -> dict[str, str]:
    """Create the environment used for evaluating requirement markers.

    Other marker variables retain their current environment values.
    """
    environment = default_environment()

    if python_version is not None:
        major, minor, micro = python_version
        environment["python_version"] = f"{major}.{minor}"
        environment["python_full_version"] = f"{major}.{minor}.{micro}"

    return environment


def select_metadata(names: Iterable[str]) -> str:
    """Select a metadata path from archive or directory entry names.

    PKG-INFO takes precedence over METADATA. The returned value is the
    original entry name, suitable for retrieving the selected entry.
    """
    pkg_info = []
    metadata = []

    for name in names:
        parts = name.replace("\\", "/").split("/")

        if len(parts) != 2:
            continue

        if parts[0] and parts[1] == "PKG-INFO":
            pkg_info.append(name)
        elif parts[0].endswith(".dist-info") and parts[1] == "METADATA":
            metadata.append(name)

    if len(pkg_info) > 1:
        raise ValueError("Multiple PKG-INFO files found.")

    if pkg_info:
        return pkg_info[0]

    if len(metadata) > 1:
        raise ValueError("Multiple METADATA files found.")

    if metadata:
        return metadata[0]

    raise ValueError("No supported metadata file found.")


def read_zip_archive(path: Path) -> bytes:
    """Read and select metadata from a ZIP distribution archive."""
    try:
        with zipfile.ZipFile(path) as archive:
            files = [info for info in archive.infolist() if not info.is_dir()]
            selected_name = select_metadata(info.filename for info in files)
            selected_info = next(
                info for info in files if info.filename == selected_name
            )
            return archive.read(selected_info)
    except (OSError, zipfile.BadZipFile, RuntimeError) as exc:
        raise ValueError(f"Cannot read ZIP archive: {path}") from exc


def read_tar_archive(path: Path) -> bytes:
    """Read and select metadata from a tar distribution archive."""
    try:
        with tarfile.open(path, mode="r:*") as archive:
            files = [member for member in archive.getmembers() if member.isfile()]
            selected_name = select_metadata(member.name for member in files)
            selected_member = next(
                member for member in files if member.name == selected_name
            )
            fileobj = archive.extractfile(selected_member)

            if fileobj is None:
                raise ValueError(
                    f"Cannot read metadata file {selected_name!r} from archive."
                )

            with fileobj:
                return fileobj.read()

    except (OSError, tarfile.TarError) as exc:
        raise ValueError(f"Cannot read tar archive: {path}") from exc


def read_directory(path: Path) -> bytes:
    """Read metadata from an extracted sdist or wheel top-level directory.

    Only PKG-INFO directly inside the directory and METADATA directly inside
    its immediate .dist-info subdirectories are considered.
    """
    candidates = []

    pkg_info = path / "PKG-INFO"
    if pkg_info.is_file():
        candidates.append("./PKG-INFO")

    for child in path.iterdir():
        if child.is_dir() and child.name.endswith(".dist-info"):
            metadata = child / "METADATA"
            if metadata.is_file():
                candidates.append(f"{child.name}/METADATA")

    selected_name = select_metadata(candidates)
    return (path / selected_name).read_bytes()


def read_input(path: Path) -> bytes:
    """Read metadata from a metadata file, archive, or extracted directory."""
    if not path.exists():
        raise FileNotFoundError(f"Input does not exist: {path}")

    if path.is_dir():
        return read_directory(path)

    if path.name in ("PKG-INFO", "METADATA"):
        return path.read_bytes()

    if zipfile.is_zipfile(path):
        return read_zip_archive(path)

    if tarfile.is_tarfile(path):
        return read_tar_archive(path)

    raise ValueError(f"Unsupported input file: {path}")


def parse_metadata(data: bytes) -> dict:
    """Parse and validate Python distribution metadata.

    Returns a dictionary containing the normalized distribution name,
    Requires-Dist values, and normalized declared extras.
    """
    try:
        raw, _ = parse_email(data)
    except (ValueError, TypeError) as exc:
        raise ValueError("Invalid metadata.") from exc

    name = raw.get("name")
    if not name or not name.strip():
        raise ValueError("Metadata does not contain a valid Name field.")

    try:
        normalized_name = canonicalize_name(name.strip(), validate=True)
    except InvalidName as exc:
        raise ValueError(f"Invalid distribution name: {name!r}") from exc

    requires_dist = raw.get("requires_dist", [])

    try:
        extras = {
            canonicalize_name(value.strip(), validate=True)
            for value in raw.get("provides_extra", [])
        }
    except InvalidName as exc:
        raise ValueError(
            "Metadata contains an invalid Provides-Extra value."
        ) from exc

    metadata_version = raw.get("metadata_version")
    dynamic = {
        value.strip().casefold()
        for value in raw.get("dynamic", [])
    }

    if "requires-dist" in dynamic:
        warnings.warn(
            "Requires-Dist is declared as dynamic; "
            "dependency information may be incomplete.",
            stacklevel=2,
        )

    if metadata_version is None:
        warnings.warn(
            "Metadata-Version is missing or invalid; metadata completeness "
            "cannot be determined.",
            stacklevel=2,
        )
    else:
        parts = metadata_version.strip().split(".")

        if (
            len(parts) != 2
            or not all(
                part.isascii() and part.isdecimal()
                for part in parts
            )
        ):
            warnings.warn(
                f"Invalid Metadata-Version: {metadata_version!r}; "
                "metadata completeness cannot be determined.",
                stacklevel=2,
            )
        else:
            version = tuple(map(int, parts))

            if not requires_dist and version < (2, 1):
                warnings.warn(
                    "Requires-Dist is absent and Metadata-Version "
                    "is earlier than 2.1.",
                    stacklevel=2,
                )

    return {
        "name": normalized_name,
        "requires_dist": requires_dist,
        "extras": extras,
    }


def parse_requirements(values: Iterable[str]) -> list[Requirement]:
    """Parse Requires-Dist values.

    Raises ValueError if any requirement is invalid.
    """
    requirements = []

    for value in values:
        try:
            requirements.append(Requirement(value))
        except InvalidRequirement as exc:
            raise ValueError(
                f"Invalid Requires-Dist value: {value!r}"
            ) from exc

    return requirements


def extract_dependencies(
    metadata: dict,
    requested_extras: Iterable[str],
    environment: dict[str, str],
) -> list[str]:
    """Extract applicable dependency package names.

    Evaluate regular requirements and requested extras. Resolve
    self-referenced extras until no new extras are enabled.
    """
    own_name = metadata["name"]
    requirements = parse_requirements(metadata["requires_dist"])

    declared_extras = metadata["extras"]

    try:
        enabled_extras = {
            canonicalize_name(extra, validate=True)
            for extra in requested_extras
        }
    except InvalidName as exc:
        raise ValueError(f"Invalid extra name: {exc}") from exc

    pending_extras = set(enabled_extras)
    processed_extras = set()
    dependencies = set()

    def process_requirements(extra: str) -> None:
        """Process requirements for one extra context."""
        marker_environment = environment.copy()
        marker_environment["extra"] = extra

        for requirement in requirements:
            if (
                requirement.marker is not None
                and not requirement.marker.evaluate(marker_environment)
            ):
                continue

            dependency_name = canonicalize_name(requirement.name)

            if dependency_name == own_name:
                try:
                    new_extras = {
                        canonicalize_name(name, validate=True)
                        for name in requirement.extras
                    } - enabled_extras
                except InvalidName as exc:
                    raise ValueError(
                        f"Invalid self-referenced extra name: {exc}"
                    ) from exc

                enabled_extras.update(new_extras)
                pending_extras.update(new_extras)
            else:
                dependencies.add(dependency_name)

    # Process regular requirements with an empty extra context.
    process_requirements("")

    # Process requested and self-referenced extras.
    while pending_extras:
        extra = pending_extras.pop()

        if extra in processed_extras:
            continue

        processed_extras.add(extra)
        process_requirements(extra)

    for extra in sorted(enabled_extras - declared_extras):
        warnings.warn(
            f"Requested or self-referenced extra {extra!r} "
            "is not declared in Provides-Extra.",
            stacklevel=2,
        )

    return sorted(dependencies)


def main() -> int:
    """Run the command-line application."""
    args = build_parser().parse_args()

    try:
        data = read_input(args.input)
        metadata = parse_metadata(data)

        if args.list_extras:
            print("\n".join(sorted(metadata["extras"])))
            return 0

        python_version = (
            parse_python_version(args.python_version)
            if args.python_version is not None
            else None
        )
        environment = create_environment(python_version)

        dependencies = extract_dependencies(
            metadata,
            args.extra,
            environment,
        )

        print("\n".join(dependencies))
        return 0

    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
