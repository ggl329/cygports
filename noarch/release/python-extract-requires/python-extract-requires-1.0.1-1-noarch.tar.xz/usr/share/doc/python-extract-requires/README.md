# python-extract-requires.py

A command-line tool for extracting dependencies and extras from Python distribution metadata.

## Overview

`python-extract-requires.py` extracts dependency information from Python distribution metadata.

It supports the following input formats:

- Source distribution archives (sdist)
- Wheel archives
- Extracted sdist and wheel directories
- `PKG-INFO` files
- `METADATA` files

The tool evaluates environment markers against a specified Python version and optionally includes dependencies associated with extras.

It uses the [`packaging`](https://packaging.pypa.io/) library to parse metadata and requirement specifiers.

## Features

- Supports direct input of `PKG-INFO` and `METADATA` files
- Supports tar-based and ZIP-based sdist archives, and ZIP-based wheel archives
- Supports extracted sdist and wheel directories
- Evaluates environment markers in `Requires-Dist`
- Allows the target Python version to be specified with `--python-version`
- Enables additional dependency groups with `--extra`
- Supports activation of extras through dependencies that refer to the package itself
- Normalizes dependency package names and extra names
- Removes duplicate dependency names and sorts the results
- Supports listing extras declared in `Provides-Extra` with `--list-extras`

## Requirements

- Python 3.12 or later
- `packaging` 23.2 or later

## Usage

```console
python python-extract-requires.py INPUT [OPTIONS]
```

### Argument

| Argument | Description                                                                                             |
|----------|---------------------------------------------------------------------------------------------------------|
| `INPUT`  | Path to a `PKG-INFO` file, `METADATA` file, sdist or wheel archive, or extracted distribution directory |

### Options

| Option                     | Description                                                                                                                                                             |
|----------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `--python-version VERSION` | Python version used for environment marker evaluation. Specify `MAJOR.MINOR` or `MAJOR.MINOR.PATCH`. If omitted, the version of the running Python environment is used. |
| `--extra NAME`             | Enables the specified extra. Repeat this option to enable multiple extras.                                                                                              |
| `--list-extras`            | Lists the normalized extras declared in the metadata and exits.                                                                                                         |
| `-h`, `--help`             | Show help message and exit.                                                                                                                                             |

## Examples

### Extract regular dependencies

```console
python python-extract-requires.py example-1.0.tar.gz
```

### Specify a Python version

```console
python python-extract-requires.py example-1.0.tar.gz --python-version 3.12
```

A patch version can also be specified:

```console
python python-extract-requires.py example-1.0.tar.gz --python-version 3.12.4
```

### Enable extras

```console
python python-extract-requires.py example-1.0.tar.gz --extra docs
```

Repeat the option to enable multiple extras:

```console
python python-extract-requires.py example-1.0.tar.gz --extra docs --extra test
```

Extra names are normalized before evaluation.

### List declared extras

```console
python python-extract-requires.py example-1.0.tar.gz --list-extras
```

The output contains normalized extra names, one per line, sorted alphabetically.

## Input Formats and Metadata Selection

### Direct metadata file input

A file named `PKG-INFO` or `METADATA` can be specified directly.

### sdist and wheel archives

The tool reads ZIP and tar archives without extracting them.

Following the standard archive layouts, it considers the following metadata locations:

- sdist: `PKG-INFO` inside the project directory at the archive root
- wheel: `METADATA` inside `<distribution>.dist-info/` at the archive root

Metadata candidates are selected according to these rules:

1. If exactly one `PKG-INFO` file exists, it is used.
2. If multiple `PKG-INFO` files exist, an error is reported because the choice is ambiguous.
3. If no `PKG-INFO` file exists, exactly one `.dist-info/METADATA` file is used, if present.
4. An error is reported if multiple `METADATA` files exist or no candidate is found.

If a `PKG-INFO` file exists, it takes precedence regardless of the number of `METADATA` files.

### Extracted distribution directories

The tool also supports extracted sdist and wheel directories.

It considers only the following locations directly inside the specified directory:

- `PKG-INFO`
- `METADATA` inside immediate `.dist-info` subdirectories

It does not search recursively through arbitrary subdirectories.

## Dependency Evaluation

### Environment markers

The tool evaluates environment markers in `Requires-Dist` and extracts only dependencies that apply to the target environment.

When `--python-version` is specified, it overrides the `python_version` and `python_full_version` marker variables:

- If `MAJOR.MINOR` is specified, the patch component of `python_full_version` is treated as `0`.
- If `MAJOR.MINOR.PATCH` is specified, the complete specified version is used.
- If the option is omitted, the values from the running Python environment are used unchanged.

Environment marker variables other than the Python version variables use values from the running environment.

### Extras

The tool evaluates regular dependencies and dependencies associated with extras specified by `--extra`.

If a dependency refers to the package itself (for example, `example[docs]; extra == "all"`), the extras specified by that dependency are also enabled. Evaluation continues for newly enabled extras until no new extras are found.

Extra names are normalized before comparison. This applies to:

- Values declared in `Provides-Extra`
- Names supplied with `--extra`
- Extras specified by self-referencing dependencies

A warning is issued if a requested or self-referenced extra is not declared in `Provides-Extra`, but processing continues.

If `Provides-Extra` is absent, extras are not inferred from marker expressions.

The tool does not recursively resolve extras of dependency packages or the dependencies required by those packages.

### Dependency package name output

Dependency package names are normalized using `packaging.utils.canonicalize_name()`. Duplicates are removed based on the normalized names, and the results are sorted alphabetically.

The output contains one dependency package name per line. A trailing newline is appended when output is printed.

## Warnings and Errors

Depending on the metadata, dependency information may not be complete. In the following cases, a warning is written to standard error and processing continues:

- `Dynamic` contains `Requires-Dist`.
- `Requires-Dist` is absent and `Metadata-Version` is earlier than 2.1.
- `Metadata-Version` is missing or invalid, so metadata completeness cannot be determined.
- A requested or self-referenced extra is not declared in `Provides-Extra`.

The tool exits with an error if:

- The input file or archive cannot be read.
- No supported metadata file can be selected, or multiple candidates of the same preferred type are found.
- The metadata does not contain a valid distribution name.
- A `Requires-Dist` entry cannot be parsed.
- A requested or self-referenced extra name is invalid.

Invalid `Requires-Dist` entries that are passed to the requirement parser are not silently ignored.

## Limitations

- The tool uses only information recorded in the metadata. It does not execute build backends to inspect dependencies.
- Dependencies that cannot be determined from metadata alone, such as dynamic dependencies, may not be extractable.
- Dependencies of dependency packages are not resolved recursively.
- Extracted directories are searched only at the supported top-level metadata locations.
- Environment marker variables other than the Python version variables depend on the running environment.

## License

MIT License
