;;; Generated package description from corfu.el  -*- no-byte-compile: t -*-
(define-package "corfu" "2.13" "COmpletion in Region FUnction" '((emacs "29.1") (compat "31")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("abbrev" "convenience" "matching" "completion" "text") :url "https://github.com/minad/corfu")
