/usr/sbin/alternatives --install /usr/bin/scapy scapy /usr/bin/scapy-3.12 312
