/usr/sbin/alternatives --remove scapy /usr/bin/scapy-3.12
