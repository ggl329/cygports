/usr/sbin/alternatives --remove markdown2 /usr/bin/markdown2-3.9
