/usr/sbin/alternatives --install /usr/bin/markdown2 markdown2 /usr/bin/markdown2-3.9 39
