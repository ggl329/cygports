;;; Generated package description from modus-themes.el  -*- no-byte-compile: t -*-
(define-package "modus-themes" "5.3.0" "Elegant, highly legible and customizable themes" '((emacs "28.1")) :authors '(("Protesilaos" . "info@protesilaos.com")) :maintainer '("Protesilaos" . "info@protesilaos.com") :keywords '("faces" "theme" "accessibility") :url "https://github.com/protesilaos/modus-themes")
