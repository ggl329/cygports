/usr/sbin/alternatives --install /usr/bin/pdoc pdoc /usr/bin/pdoc-3.12 312
