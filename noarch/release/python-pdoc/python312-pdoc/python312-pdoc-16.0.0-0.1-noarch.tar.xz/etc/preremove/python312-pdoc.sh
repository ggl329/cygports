/usr/sbin/alternatives --remove pdoc /usr/bin/pdoc-3.12
