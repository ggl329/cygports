/usr/sbin/alternatives --install /usr/bin/pybind11-config pybind11-config /usr/bin/pybind11-config-3.9 39
