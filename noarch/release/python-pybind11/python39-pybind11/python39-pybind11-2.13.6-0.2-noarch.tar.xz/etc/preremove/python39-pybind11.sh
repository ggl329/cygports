/usr/sbin/alternatives --remove pybind11-config /usr/bin/pybind11-config-3.9
