;;; Generated package description from org-modern.el  -*- no-byte-compile: t -*-
(define-package "org-modern" "1.13" "Modern looks for Org" '((emacs "29.1") (org "9.6") (compat "30")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("outlines" "hypermedia" "text") :url "https://github.com/minad/org-modern")
