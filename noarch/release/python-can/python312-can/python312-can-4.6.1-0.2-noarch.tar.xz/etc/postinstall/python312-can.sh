/usr/sbin/alternatives --install /usr/bin/can_bridge can_bridge /usr/bin/can_bridge-3.12 312
/usr/sbin/alternatives --install /usr/bin/can_logconvert can_logconvert /usr/bin/can_logconvert-3.12 312
/usr/sbin/alternatives --install /usr/bin/can_logger can_logger /usr/bin/can_logger-3.12 312
/usr/sbin/alternatives --install /usr/bin/can_player can_player /usr/bin/can_player-3.12 312
/usr/sbin/alternatives --install /usr/bin/can_viewer can_viewer /usr/bin/can_viewer-3.12 312
