/usr/sbin/alternatives --remove can_bridge /usr/bin/can_bridge-3.12
/usr/sbin/alternatives --remove can_logconvert /usr/bin/can_logconvert-3.12
/usr/sbin/alternatives --remove can_logger /usr/bin/can_logger-3.12
/usr/sbin/alternatives --remove can_player /usr/bin/can_player-3.12
/usr/sbin/alternatives --remove can_viewer /usr/bin/can_viewer-3.12
