/usr/sbin/alternatives --remove pyflakes /usr/bin/pyflakes-3.12
