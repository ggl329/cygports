/usr/sbin/alternatives --install /usr/bin/pyflakes pyflakes /usr/bin/pyflakes-3.12 312
