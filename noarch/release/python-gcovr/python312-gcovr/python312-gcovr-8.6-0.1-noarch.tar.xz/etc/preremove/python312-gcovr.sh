/usr/sbin/alternatives --remove gcovr /usr/bin/gcovr-3.12
