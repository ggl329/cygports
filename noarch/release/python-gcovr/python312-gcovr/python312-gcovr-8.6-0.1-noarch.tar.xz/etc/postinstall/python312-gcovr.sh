/usr/sbin/alternatives --install /usr/bin/gcovr gcovr /usr/bin/gcovr-3.12 312
