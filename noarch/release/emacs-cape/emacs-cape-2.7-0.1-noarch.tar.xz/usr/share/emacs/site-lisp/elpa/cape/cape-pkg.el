;;; Generated package description from cape.el  -*- no-byte-compile: t -*-
(define-package "cape" "2.7" "Completion At Point Extensions" '((emacs "29.1") (compat "31")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("abbrev" "convenience" "matching" "completion" "text") :url "https://github.com/minad/cape")
