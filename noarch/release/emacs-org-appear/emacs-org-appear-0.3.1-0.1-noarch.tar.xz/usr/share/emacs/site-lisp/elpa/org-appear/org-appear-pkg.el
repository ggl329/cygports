;;; Generated package description from org-appear.el  -*- no-byte-compile: t -*-
(define-package "org-appear" "0.3.1" "Auto-toggle Org elements" '((emacs "29.1") (org "9.3")) :authors '(("Alice Istleyeva" . "awth13@gmail.com")) :maintainer '("Alice Istleyeva" . "awth13@gmail.com") :url "https://github.com/awth13/org-appear")
