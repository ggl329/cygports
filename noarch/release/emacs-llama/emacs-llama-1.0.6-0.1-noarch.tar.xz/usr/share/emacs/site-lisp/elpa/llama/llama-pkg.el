;;; Generated package description from llama.el  -*- no-byte-compile: t -*-
(define-package "llama" "1.0.6" "Compact syntax for short lambda" '((emacs "28.1") (compat "31.1")) :authors '(("Jonas Bernoulli" . "emacs.llama@jonas.bernoulli.dev")) :maintainer '("Jonas Bernoulli" . "emacs.llama@jonas.bernoulli.dev") :keywords '("extensions") :url "https://github.com/tarsius/llama")
