;;; Generated package description from consult.el  -*- no-byte-compile: t -*-
(define-package "consult" "3.8" "Search and navigate via completing-read" '((emacs "29.1") (compat "31")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("matching" "files" "completion") :url "https://github.com/minad/consult")
