/usr/sbin/alternatives --remove pythran /usr/bin/pythran-3.12
/usr/sbin/alternatives --remove pythran-config /usr/bin/pythran-config-3.12
