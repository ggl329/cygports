/usr/sbin/alternatives --install /usr/bin/pythran pythran /usr/bin/pythran-3.12 312
/usr/sbin/alternatives --install /usr/bin/pythran-config pythran-config /usr/bin/pythran-config-3.12 312
