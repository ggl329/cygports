/usr/sbin/alternatives --remove pythran /usr/bin/pythran-3.9
/usr/sbin/alternatives --remove pythran-config /usr/bin/pythran-config-3.9
