;;; Generated package description from ddskk.el  -*- no-byte-compile: t -*-
(define-package "ddskk" "17.1" "Daredevil SKK (Simple Kana to Kanji conversion program)" '((emacs "24.3")) :authors '(("Masahiko Sato" . "masahiko@kuis.kyoto-u.ac.jp")) :keywords '("japanese" "mule" "input method") :url "https://github.com/skk-dev/ddskk")
