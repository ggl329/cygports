############################################################################
# Copyright (c) Johan Mabille, Sylvain Corlay, Wolf Vollprecht and         #
# Martin Renou                                                             #
# Copyright (c) QuantStack                                                 #
#                                                                          #
# Distributed under the terms of the BSD 3-Clause License.                 #
#                                                                          #
# The full license is in the file LICENSE, distributed with this software. #
############################################################################

# xsimd cmake module
# This module sets the following variables in your project::
#
#   xsimd_FOUND - true if xsimd found on the system
#   xsimd_INCLUDE_DIRS - the directory containing xsimd headers
#   xsimd_LIBRARY - empty


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was xsimdConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

if(NOT TARGET xsimd)
    include("${CMAKE_CURRENT_LIST_DIR}/xsimdTargets.cmake")
    get_target_property(
        xsimd_INCLUDE_DIRS
        xsimd INTERFACE_INCLUDE_DIRECTORIES
    )

    # xsimd <= 14 behaviour.
    # Packagers that configured xsimd for their users with ENABLE_XTL_COMPLEX
    # have it automatically enabled.
    # Can be removed in xsimd 15. Keeping it with a version check so we do not
    # miss the opportunity to remove it in the next major release.
    # Compared to legacy version, users can now override the check
    # with XSIMD_ENABLE_XTL_COMPLEX.
    if(
        OFF
        AND 14 LESS_EQUAL 14
        AND NOT DEFINED XSIMD_ENABLE_XTL_COMPLEX
    )
        # The next check will handle adding it to the target
        set(XSIMD_ENABLE_XTL_COMPLEX OFF)
    endif()

    # Final users of xsimd in a package manager control whether or not to
    # enable xtl with this variable.
    if(XSIMD_ENABLE_XTL_COMPLEX)
        include(CMakeFindDependencyMacro)
        find_dependency(xtl 0.8.0 REQUIRED)
        target_link_libraries(xsimd INTERFACE xtl)
        target_compile_definitions(
            xsimd
            INTERFACE XSIMD_ENABLE_XTL_COMPLEX=1
        )
    endif()
endif()
