/usr/sbin/alternatives --install /usr/bin/pinentry pinentry /usr/bin/pinentry-curses 30
