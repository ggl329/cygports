/usr/sbin/alternatives --remove pinentry /usr/bin/pinentry-tty
