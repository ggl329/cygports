/usr/sbin/alternatives --install /usr/bin/pinentry pinentry /usr/bin/pinentry-w32 40
