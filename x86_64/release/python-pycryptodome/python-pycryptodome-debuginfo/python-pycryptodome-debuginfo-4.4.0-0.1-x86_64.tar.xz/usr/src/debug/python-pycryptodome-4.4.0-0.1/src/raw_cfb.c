/*
 * SPDX-FileCopyrightText: 2014 Legrandin <helderijs@gmail.com>
 * SPDX-License-Identifier: BSD-2-Clause
 */

#include "common.h"

FAKE_INIT(raw_cfb)

#include "block_base.h"

#define ERR_CFB_IV_LEN           ((2 << 16) | 1)
#define ERR_CFB_INVALID_SEGMENT  ((2 << 16) | 2)

typedef struct {
    BlockBase *cipher;

    size_t segment_len;

    /** How many bytes at the beginning of the key stream
      * have already been used.
      */
    size_t usedKeyStream;

    uint8_t *keyStream;
    uint8_t *next_iv;
} CfbModeState;

EXPORT_SYM int CFB_start_operation(BlockBase *cipher,
                                   const uint8_t iv[],
                                   size_t iv_len,
                                   size_t segment_len, /* In bytes */
                                   CfbModeState **pResult)
{
    CfbModeState *state;

    if ((NULL == cipher) || (NULL == iv) || (NULL == pResult)) {
        return ERR_NULL;
    }

    if (cipher->block_len != iv_len) {
        return ERR_CFB_IV_LEN;
    }

    if ((segment_len == 0) || (segment_len > cipher->block_len)) {
        return ERR_CFB_INVALID_SEGMENT;
    }

    state = *pResult = calloc(1, sizeof(CfbModeState));
    if (NULL == *pResult) {
        return ERR_MEMORY;
    }

    state->next_iv = calloc(1, cipher->block_len);
    if (NULL == state->next_iv) {
        free(state);
        return ERR_MEMORY;
    }

    state->keyStream = calloc(1, cipher->block_len);
    if (NULL == state->keyStream) {
        free(state->next_iv);
        free(state);
        return ERR_MEMORY;
    }

    state->cipher = cipher;
    state->segment_len = segment_len;
    state->usedKeyStream = 0;
    memcpy(state->next_iv, iv + segment_len, iv_len - segment_len);
    return cipher->encrypt(state->cipher, iv, state->keyStream, iv_len);
}

enum Direction { DirEncrypt, DirDecrypt };

static int CFB_transcrypt(CfbModeState *cfbState,
                          const uint8_t *in,
                          uint8_t *out,
                          size_t data_len,
                          enum Direction direction)
{
    uint8_t *next_iv;
    size_t block_len;
    size_t segment_len;
    size_t used;

    if ((NULL == cfbState) || (NULL == in) || (NULL == out))
        return ERR_NULL;

    block_len = cfbState->cipher->block_len;
    segment_len = cfbState->segment_len;
    next_iv = cfbState->next_iv;

    assert((direction == DirEncrypt) || (direction == DirDecrypt));

    /*
     * Read the position in the key stream only once, and check it:
     * if several threads used the object at once (not supported),
     * the state could be inconsistent, but memory must never be
     * accessed out of bounds.
     */
    used = cfbState->usedKeyStream;
    if (used > segment_len || segment_len > block_len)
        return ERR_STATE;

    while (data_len > 0) {
        unsigned i;
        size_t keyStreamToUse;
        uint8_t *segment, *keyStream;

        if (used == segment_len) {
            int result;

            result = cfbState->cipher->encrypt(cfbState->cipher,
                                               next_iv,
                                               cfbState->keyStream,
                                               block_len);
            if (0 != result) {
                cfbState->usedKeyStream = used;
                return result;
            }

            /* The next input to the cipher is:
             * - the old input shifted left by the segment length
             * - filled on the right with the enough ciphertext
             *
             * If the segment length equals the block length,
             * the next input is simply the ciphertext block.
             *
             * If the segment length equals 1, only the leftmost
             * byte of the ciphertext block is used.
             */
            memmove(next_iv, next_iv + segment_len, block_len - segment_len);

            /*
             * The rest of the next input is copied when enough ciphertext is
             * available (we need segment_len bytes).
             */
            used = 0;
        }

        keyStream = cfbState->keyStream + used;
        keyStreamToUse = MIN(segment_len - used, data_len);

        segment = next_iv + (block_len - (segment_len - used));

        if (direction == DirDecrypt) {
            memcpy(segment, in, keyStreamToUse);
        }

        for (i=0; i<keyStreamToUse; i++) {
            *out++ = *keyStream++ ^ *in++;
        }

        if (direction == DirEncrypt) {
            memcpy(segment, out - keyStreamToUse, keyStreamToUse);
        }

        data_len -= keyStreamToUse;
        used += keyStreamToUse;
    }

    cfbState->usedKeyStream = used;
    return 0;
}

EXPORT_SYM int CFB_encrypt(CfbModeState *cfbState,
                           const uint8_t *in,
                           uint8_t *out,
                           size_t data_len)
{
    return CFB_transcrypt(cfbState, in, out, data_len, DirEncrypt);
}

EXPORT_SYM int CFB_decrypt(CfbModeState *cfbState,
                           const uint8_t *in,
                           uint8_t *out,
                           size_t data_len)
{
    return CFB_transcrypt(cfbState, in, out, data_len, DirDecrypt);
}

EXPORT_SYM int CFB_stop_operation(CfbModeState *state)
{
    if (NULL == state)
        return ERR_NULL;

    state->cipher->destructor(state->cipher);
    free(state->next_iv);
    free(state->keyStream);
    free(state);
    return 0;
}
