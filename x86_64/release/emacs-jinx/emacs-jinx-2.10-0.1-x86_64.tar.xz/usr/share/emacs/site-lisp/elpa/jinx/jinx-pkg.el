;;; Generated package description from jinx.el  -*- no-byte-compile: t -*-
(define-package "jinx" "2.10" "Enchanted Spell Checker" '((emacs "29.1") (compat "31")) :authors '(("Daniel Mendler" . "mail@daniel-mendler.de")) :maintainer '("Daniel Mendler" . "mail@daniel-mendler.de") :keywords '("convenience" "text") :url "https://github.com/minad/jinx")
