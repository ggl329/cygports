/usr/sbin/alternatives --remove coverage /usr/bin/coverage-3.12
