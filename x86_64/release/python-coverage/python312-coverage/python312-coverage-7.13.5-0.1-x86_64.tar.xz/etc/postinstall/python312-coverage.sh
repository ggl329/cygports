/usr/sbin/alternatives --install /usr/bin/coverage coverage /usr/bin/coverage-3.12 312
